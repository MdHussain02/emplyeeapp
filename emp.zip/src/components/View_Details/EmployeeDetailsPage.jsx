import React, { useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import useEmployeeDetailsPageState from './hooks/useEmployeeDetailsPageState';
import EmployeeDetailsForm from "./Update/EmployeeDetailsForm";

const EmployeeDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const {
    formData,
    editMode,
    showSuccessToast,
    error,
    isLoading,
    handleEdit,
    handleCancel,
    handleSuccess,
  } = useEmployeeDetailsPageState(id);

  const profileImage = useMemo(() => {
    if (formData?.profile_picture && typeof formData.profile_picture === "string") {
      return (
        <img
          src={formData.profile_picture}
          alt="Profile"
          className="rounded-circle shadow-sm border border-primary "
          style={{
            width: "150px",
            height: "150px",
            objectFit: "cover",
          }}
        />
      );
    }
    return null;
  }, [formData?.profile_picture]);

  if (isLoading || !formData) {
    return (
      <div className="min-vh-100 d-flex justify-content-center align-items-center">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-vh-100 d-flex flex-column justify-content-center align-items-center">
        <div className="alert alert-danger" role="alert">
          <i className="bi bi-exclamation-triangle-fill me-2"></i>
          Failed to load employee details
        </div>
        <button onClick={() => navigate(-1)} className="btn btn-outline-secondary mt-3">
          <i className="bi bi-arrow-left me-2"></i>Back
        </button>
      </div>
    );
  }

  const personalInfo = [
    { label: "Employee Code", value: formData.employee_code },
    { label: "Email", value: formData.email },
    { label: "Mobile", value: formData.phone },
    { label: "Date of Birth", value: formData.formatted_dob },
    { label: "Address", value: formData.address },
    { label: "City", value: formData.city },
    { label: "State", value: formData.state },
    { label: "Country", value: formData.country },
  ];

  const employmentInfo = [
    { label: "Department", value: formData.department?.name },
    { label: "Designation", value: formData.designation?.title },
    { label: "Employment Type", value: formData.employment_type?.title },
    { label: "Joining Date", value: formData.formatted_joining_date },
    { 
      label: "Salary", 
      value: `₹${parseFloat(formData.salary).toLocaleString("en-IN", {
        minimumFractionDigits: 2,
      })}`,
    },
  ];

  const bankingInfo = [
    { label: "Bank Account", value: formData.bank_account_number },
    { label: "IFSC Code", value: formData.ifsc_code },
  ];

  const emergencyInfo = [
    { label: "Emergency Contact", value: formData.emergency_contact },
  ];

  const systemInfo = [
    { label: "Created By", value: formData.created_by?.name },
    { label: "Updated By", value: formData.updated_by?.name },
  ];

  const renderInfoSection = (title, items) => (
    <div className="card shadow-sm mb-4">
      <div className="card-header bg-light">
        <h5 className="card-title mb-0">{title}</h5>
      </div>
      <div className="card-body">
        <div className="row g-3">
          {items.map(({ label, value }) => (
            <div key={label} className="col-md-6">
              <div className="p-3 bg-light rounded">
                <small className="text-muted text-uppercase">{label}</small>
                <div className="mt-1 fw-medium">{value || "N/A"}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-lg-10">
          <div className="card shadow mb-4">
            <div className="card-body">
              <div className="text-center mb-4">
                <div className="mb-3">
                  {profileImage}
                </div>
                <h2 className="h3 mb-1">{formData.name}</h2>
                <p className="text-muted mb-3">
                  <span className="badge bg-primary">{formData.designation?.title || "Designation"}</span>
                </p>
                {!editMode && (
                  <button onClick={handleEdit} className="btn btn-primary px-4">
                    <i className="bi bi-pencil-square me-2"></i>
                    Edit Details
                  </button>
                )}
              </div>

              {editMode ? (
                <EmployeeDetailsForm
                  initialValues={formData}
                  onSuccess={handleSuccess}
                  onCancel={handleCancel}
                />
              ) : (
                <>
                  {renderInfoSection("Personal Information", personalInfo)}
                  {renderInfoSection("Employment Details", employmentInfo)}
                  {renderInfoSection("Banking Information", bankingInfo)}
                  {renderInfoSection("Emergency Contact", emergencyInfo)}
                  {renderInfoSection("System Information", systemInfo)}
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {showSuccessToast && (
        <div className="position-fixed bottom-0 end-0 p-3" style={{ zIndex: 1050 }}>
          <div className="toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div className="toast-header bg-success text-white">
              <i className="bi bi-check-circle-fill me-2"></i>
              <strong className="me-auto">Success</strong>
              <small>Just now</small>
              <button type="button" className="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div className="toast-body">
              Record Updated Successfully
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeDetailsPage;