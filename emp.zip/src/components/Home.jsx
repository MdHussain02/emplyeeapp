import useSWRMutation from "swr/mutation";
import axios from "axios";
import { useRecoilState } from "recoil";
import { userPersistenceState } from "../recoil/userState";
import { useNavigate } from "react-router-dom";
import EmployeeTable from "./EmplyeeTable";

const logoutFetcher = async (url, { arg }) => {
  const response = await axios.post(
    url,
    {},
    {
      headers: { Authorization: `Bearer ${arg}` },
    }
  );
  return response.data;
};

const Home = () => {
  const [user, setUser] = useRecoilState(userPersistenceState);
  const navigate = useNavigate();

  const { trigger } = useSWRMutation(
    "https://core-skill-test.webc.in/employee-portal/api/v1/settings/logout",
    logoutFetcher
  );

  const handleLogout = async () => {
    if (!user?.token) return;

    try {
      const response = await trigger(user.token);
      console.log("Logout response:", response);

      if (response.success) {
        setUser(null);
        navigate("/");
      }
    } catch (err) {
      console.error("Logout failed:", err.response?.data || err.message);
    }
  };

  return (
    <div className="container">
      <div className="mt-5">
        <div className="">
          <h2 className="card-title">Welcome, {user?.name}</h2>
          <p className="card-text text-muted">Email: {user?.email}</p>
          <button onClick={handleLogout} className="btn btn-danger mt-3">
            Logout
          </button>

          <div className="mt-4">
            <EmployeeTable />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
